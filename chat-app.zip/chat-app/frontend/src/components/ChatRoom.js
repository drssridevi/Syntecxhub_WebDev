import React, { useState, useEffect, useRef, useCallback } from 'react';
import api from '../api/axios';
import { useSocket } from '../context/SocketContext';
import { useAuth } from '../context/AuthContext';

export default function ChatRoom({ room }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [typingUsers, setTypingUsers] = useState([]);
  const [systemNotes, setSystemNotes] = useState([]);
  const { socket, connected } = useSocket();
  const { user } = useAuth();
  const bottomRef = useRef(null);
  const typingTimeoutRef = useRef(null);

  // Load message history whenever the selected room changes
  useEffect(() => {
    if (!room) return;
    setLoading(true);
    api
      .get(`/rooms/${room._id}/messages`)
      .then(({ data }) => setMessages(data.messages))
      .catch(() => setMessages([]))
      .finally(() => setLoading(false));
    setSystemNotes([]);
  }, [room]);

  // Join the room over the socket, and subscribe to real-time events
  useEffect(() => {
    if (!socket || !room) return;

    socket.emit('join_room', { roomId: room._id });

    const handleNewMessage = (msg) => {
      if (msg.room === room._id) {
        setMessages((prev) => [...prev, msg]);
      }
    };

    const handleUserJoined = ({ userName }) => {
      setSystemNotes((prev) => [...prev, `${userName} joined the room`]);
    };

    const handleUserLeft = ({ userName }) => {
      setSystemNotes((prev) => [...prev, `${userName} left the room`]);
    };

    const handleTyping = ({ userName }) => {
      setTypingUsers((prev) => (prev.includes(userName) ? prev : [...prev, userName]));
    };

    const handleStopTyping = ({ userName }) => {
      setTypingUsers((prev) => prev.filter((n) => n !== userName));
    };

    socket.on('new_message', handleNewMessage);
    socket.on('user_joined', handleUserJoined);
    socket.on('user_left', handleUserLeft);
    socket.on('user_typing', handleTyping);
    socket.on('user_stop_typing', handleStopTyping);

    return () => {
      socket.off('new_message', handleNewMessage);
      socket.off('user_joined', handleUserJoined);
      socket.off('user_left', handleUserLeft);
      socket.off('user_typing', handleTyping);
      socket.off('user_stop_typing', handleStopTyping);
    };
  }, [socket, room]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typingUsers]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!text.trim() || !socket || !room) return;
    socket.emit('send_message', { roomId: room._id, text: text.trim() });
    socket.emit('stop_typing', { roomId: room._id });
    setText('');
  };

  const handleChange = useCallback(
    (e) => {
      setText(e.target.value);
      if (!socket || !room) return;
      socket.emit('typing', { roomId: room._id });
      clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = setTimeout(() => {
        socket.emit('stop_typing', { roomId: room._id });
      }, 1500);
    },
    [socket, room]
  );

  if (!room) {
    return <div className="chat-room empty-state">Select a room to start chatting</div>;
  }

  return (
    <div className="chat-room">
      <div className="chat-room-header">
        <h3># {room.name}</h3>
        <span className={`connection-dot ${connected ? 'online' : 'offline'}`}>
          {connected ? 'Connected' : 'Connecting...'}
        </span>
      </div>

      <div className="message-list">
        {loading ? (
          <p>Loading history...</p>
        ) : (
          <>
            {messages.map((msg) => (
              <div
                key={msg._id}
                className={`message ${msg.sender === user.id ? 'own' : ''}`}
              >
                <span className="message-sender">{msg.senderName}</span>
                <span className="message-text">{msg.text}</span>
                <span className="message-time">
                  {new Date(msg.createdAt).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
            ))}
            {systemNotes.map((note, i) => (
              <div key={`note-${i}`} className="system-note">
                {note}
              </div>
            ))}
          </>
        )}
        <div ref={bottomRef} />
      </div>

      {typingUsers.length > 0 && (
        <div className="typing-indicator">
          {typingUsers.join(', ')} {typingUsers.length === 1 ? 'is' : 'are'} typing...
        </div>
      )}

      <form className="message-form" onSubmit={handleSend}>
        <input
          type="text"
          placeholder="Type a message..."
          value={text}
          onChange={handleChange}
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
}
