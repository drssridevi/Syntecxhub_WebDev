import React, { useState, useEffect } from 'react';
import api from '../api/axios';

export default function RoomList({ onSelectRoom, activeRoomId }) {
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [newRoomName, setNewRoomName] = useState('');
  const [creating, setCreating] = useState(false);

  const fetchRooms = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/rooms');
      setRooms(data.rooms);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load rooms');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRooms();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!newRoomName.trim()) return;
    setCreating(true);
    setError('');
    try {
      const { data } = await api.post('/rooms', { name: newRoomName.trim() });
      setNewRoomName('');
      setRooms((prev) => [...prev, data.room]);
      onSelectRoom(data.room);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create room');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="room-list">
      <h3>Rooms</h3>
      {error && <div className="error-banner">{error}</div>}
      <form className="new-room-form" onSubmit={handleCreate}>
        <input
          type="text"
          placeholder="New room name"
          value={newRoomName}
          onChange={(e) => setNewRoomName(e.target.value)}
        />
        <button type="submit" disabled={creating}>
          +
        </button>
      </form>
      {loading ? (
        <p>Loading rooms...</p>
      ) : rooms.length === 0 ? (
        <p>No rooms yet. Create one above.</p>
      ) : (
        <ul>
          {rooms.map((room) => (
            <li
              key={room._id}
              className={room._id === activeRoomId ? 'active' : ''}
              onClick={() => onSelectRoom(room)}
            >
              # {room.name}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
