import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import RoomList from './RoomList';
import ChatRoom from './ChatRoom';

export default function Dashboard() {
  const [activeRoom, setActiveRoom] = useState(null);
  const { user, logout } = useAuth();

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Chat App</h1>
        <div className="header-right">
          <span>Signed in as {user?.name}</span>
          <button className="secondary" onClick={logout}>
            Logout
          </button>
        </div>
      </header>
      <div className="dashboard-body">
        <RoomList onSelectRoom={setActiveRoom} activeRoomId={activeRoom?._id} />
        <ChatRoom room={activeRoom} />
      </div>
    </div>
  );
}
