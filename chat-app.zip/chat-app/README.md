# Real-Time Chat App (MERN + Socket.io)

A real-time chat application: users register/log in, join or create chat rooms, and exchange
messages instantly. Full history is persisted in MongoDB so it's there when you rejoin a room.

- **Frontend:** React (React Router, Axios, socket.io-client)
- **Backend:** Node.js + Express + Socket.io
- **Database:** MongoDB (Mongoose)
- **Auth:** JWT for both REST endpoints and the Socket.io handshake

## Features

- Register / log in with email + password (bcrypt-hashed passwords)
- JWT is used both for REST calls (`Authorization: Bearer <token>`) and to authenticate the
  Socket.io connection itself (`socket.handshake.auth.token`) — unauthenticated sockets are rejected
- Create chat rooms, browse the room list, join a room
- Real-time messaging via Socket.io: messages broadcast instantly to everyone in the room
- Chat history persisted in MongoDB and loaded via REST when you open a room
- "User joined / left" notices and live typing indicators
- Multiple browser tabs/users see messages appear instantly, no refresh needed

## Project Structure

```
chat-app/
├── backend/
│   ├── models/          # User, Room, Message Mongoose schemas
│   ├── middleware/       # JWT auth middleware for REST routes
│   ├── routes/           # /api/auth, /api/rooms (+ /:roomId/messages)
│   ├── socket/            # Socket.io connection handler (join/send/typing/disconnect)
│   ├── server.js          # Express + Socket.io server bootstrap
│   └── .env.example
└── frontend/
    ├── public/
    └── src/
        ├── api/           # axios instance w/ JWT interceptor
        ├── context/       # AuthContext (login/register state), SocketContext (live connection)
        └── components/    # Login, Register, Dashboard, RoomList, ChatRoom, PrivateRoute
```

## How the real-time layer works

1. On login/register, the backend signs a JWT and the frontend stores it.
2. `SocketContext` opens a `socket.io-client` connection and passes the JWT in
   `auth: { token }` during the handshake.
3. On the server, `socket/chatSocket.js` runs `io.use(socketAuth)` — every socket connection is
   verified before any event handler runs; bad/missing tokens are rejected immediately.
4. Joining a room emits `join_room`, which calls `socket.join(roomId)` (a Socket.io "room" —
   distinct from our MongoDB `Room` document, though they share an id).
5. Sending a message emits `send_message`; the server persists it to MongoDB, then
   `io.to(roomId).emit('new_message', ...)` broadcasts it to everyone currently in that room.
6. Opening a room's history uses a normal REST call (`GET /api/rooms/:roomId/messages`) so a
   user who joins later still sees prior messages, not just new ones from that point on.

## Setup

### Prerequisites
- Node.js 18+
- MongoDB running locally, or a MongoDB Atlas connection string

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
# edit .env: set MONGO_URI, a strong JWT_SECRET, and CLIENT_URL
npm run dev      # or: npm start
```

The API + Socket.io server run on `http://localhost:5000` by default.

### 2. Frontend

```bash
cd frontend
npm install
cp .env.example .env
# edit .env if your backend runs on a different URL
npm start
```

The app runs on `http://localhost:3000`. Open it in two browser windows (or one normal + one
incognito), register two different users, join the same room in both, and send messages —
they'll appear instantly in both windows.

## API Reference

| Method | Endpoint                      | Auth | Description                        |
|--------|--------------------------------|:----:|-------------------------------------|
| POST   | /api/auth/register             | No   | Create account, returns JWT          |
| POST   | /api/auth/login                | No   | Log in, returns JWT                  |
| GET    | /api/auth/me                   | Yes  | Get current user                     |
| GET    | /api/rooms                     | Yes  | List all chat rooms                  |
| POST   | /api/rooms                     | Yes  | Create a new chat room                |
| GET    | /api/rooms/:roomId/messages    | Yes  | Get chat history (`?limit=` up to 200) |

### Socket.io events

| Event (client → server) | Payload                  | Description                        |
|--------------------------|---------------------------|-------------------------------------|
| `join_room`              | `{ roomId }`               | Join a room, leaving any previous one |
| `send_message`           | `{ roomId, text }`         | Persist + broadcast a message         |
| `typing` / `stop_typing`  | `{ roomId }`               | Typing indicator                      |

| Event (server → client) | Payload                                   |
|---------------------------|--------------------------------------------|
| `room_joined`              | `{ roomId, roomName }`                     |
| `new_message`              | `{ _id, room, sender, senderName, text, createdAt }` |
| `user_joined` / `user_left` | `{ userId, userName }`                    |
| `user_typing` / `user_stop_typing` | `{ userName }`                     |
| `error_message`            | `{ message }`                              |

## Deploying for live use

I can't spin up live hosting or a database from this environment — deployment needs your own
accounts/credentials — but here's a straightforward, free-tier-friendly path:

1. **Database — MongoDB Atlas**
   - Create a free cluster at mongodb.com/atlas, add a database user, and allow network access
     from anywhere (or your host's IPs).
   - Copy the connection string for `MONGO_URI`.

2. **Backend — Render, Railway, or Fly.io** (any Node host that supports WebSockets works;
   traditional serverless functions do NOT support long-lived Socket.io connections)
   - Point it at the `backend/` folder, build command `npm install`, start command `npm start`.
   - Set environment variables: `MONGO_URI`, `JWT_SECRET`, `CLIENT_URL` (your deployed frontend
     URL), and `PORT` (most hosts set this for you).

3. **Frontend — Vercel or Netlify**
   - Point it at the `frontend/` folder, build command `npm run build`, output directory `build`.
   - Set `REACT_APP_API_URL` and `REACT_APP_SOCKET_URL` to your deployed backend's URL
     (e.g. `https://your-api.onrender.com` and `https://your-api.onrender.com/api`).

4. **CORS/socket config** — double check `CLIENT_URL` on the backend matches your deployed
   frontend origin exactly (including `https://`), since both Express CORS and the Socket.io
   CORS config in `server.js` use it.

Once those three pieces are live, share the frontend URL and anyone can register and chat in
real time.

## Security notes

- Passwords are hashed with bcrypt, never stored in plain text
- JWTs are signed with a secret from `.env` — never commit your real `.env`
- Every REST task/room route and every socket connection requires a valid JWT
- CORS and Socket.io CORS are both scoped to `CLIENT_URL`; tighten this further in production
  if you know the exact deployed origin

## Next steps / ideas

- Private/direct messages between two users
- Read receipts and unread counts
- File/image sharing in messages
- Room membership/invites instead of open rooms
- Pagination ("load older messages") beyond the last 200
