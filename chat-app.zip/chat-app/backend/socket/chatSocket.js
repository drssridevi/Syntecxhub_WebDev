const jwt = require('jsonwebtoken');
const Room = require('../models/Room');
const Message = require('../models/Message');

// Verify JWT sent in the socket handshake (io(url, { auth: { token } }) on the client)
function socketAuth(socket, next) {
  const token = socket.handshake.auth?.token;
  if (!token) {
    return next(new Error('Authentication required'));
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    socket.userId = decoded.userId;
    socket.userName = decoded.name;
    next();
  } catch (err) {
    next(new Error('Invalid or expired token'));
  }
}

// Tracks which room each socket is currently in, so we can clean up on disconnect
const socketRoomMap = new Map();

function initChatSocket(io) {
  io.use(socketAuth);

  io.on('connection', (socket) => {
    console.log(`Socket connected: ${socket.id} (user: ${socket.userName})`);

    // Join a chat room. Leaves any previously joined room first.
    socket.on('join_room', async ({ roomId }) => {
      try {
        const room = await Room.findById(roomId);
        if (!room) {
          return socket.emit('error_message', { message: 'Room not found' });
        }

        const previousRoom = socketRoomMap.get(socket.id);
        if (previousRoom && previousRoom !== roomId) {
          socket.leave(previousRoom);
          socket.to(previousRoom).emit('user_left', {
            userId: socket.userId,
            userName: socket.userName,
          });
        }

        socket.join(roomId);
        socketRoomMap.set(socket.id, roomId);

        socket.to(roomId).emit('user_joined', {
          userId: socket.userId,
          userName: socket.userName,
        });

        socket.emit('room_joined', { roomId, roomName: room.name });
      } catch (err) {
        console.error(err);
        socket.emit('error_message', { message: 'Could not join room' });
      }
    });

    // Send a message to the currently joined room; persist it, then broadcast
    socket.on('send_message', async ({ roomId, text }) => {
      try {
        if (!text || !text.trim()) return;

        const room = await Room.findById(roomId);
        if (!room) {
          return socket.emit('error_message', { message: 'Room not found' });
        }

        const message = await Message.create({
          room: roomId,
          sender: socket.userId,
          senderName: socket.userName,
          text: text.trim(),
        });

        io.to(roomId).emit('new_message', {
          _id: message._id,
          room: roomId,
          sender: socket.userId,
          senderName: socket.userName,
          text: message.text,
          createdAt: message.createdAt,
        });
      } catch (err) {
        console.error(err);
        socket.emit('error_message', { message: 'Could not send message' });
      }
    });

    // Typing indicators
    socket.on('typing', ({ roomId }) => {
      socket.to(roomId).emit('user_typing', { userName: socket.userName });
    });

    socket.on('stop_typing', ({ roomId }) => {
      socket.to(roomId).emit('user_stop_typing', { userName: socket.userName });
    });

    socket.on('disconnect', () => {
      const roomId = socketRoomMap.get(socket.id);
      if (roomId) {
        socket.to(roomId).emit('user_left', {
          userId: socket.userId,
          userName: socket.userName,
        });
        socketRoomMap.delete(socket.id);
      }
      console.log(`Socket disconnected: ${socket.id}`);
    });
  });
}

module.exports = initChatSocket;
