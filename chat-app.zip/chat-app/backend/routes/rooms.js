const express = require('express');
const Room = require('../models/Room');
const Message = require('../models/Message');
const auth = require('../middleware/auth');

const router = express.Router();

router.use(auth);

// @route   GET /api/rooms
// @desc    List all chat rooms
router.get('/', async (req, res) => {
  try {
    const rooms = await Room.find().sort({ createdAt: 1 });
    res.json({ rooms });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error while fetching rooms' });
  }
});

// @route   POST /api/rooms
// @desc    Create a new chat room
router.post('/', async (req, res) => {
  try {
    const { name, description } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ message: 'Room name is required' });
    }

    const existing = await Room.findOne({ name: name.trim() });
    if (existing) {
      return res.status(409).json({ message: 'A room with this name already exists' });
    }

    const room = await Room.create({
      name: name.trim(),
      description,
      createdBy: req.userId,
    });

    res.status(201).json({ room });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error while creating room' });
  }
});

// @route   GET /api/rooms/:roomId/messages
// @desc    Get chat history for a room (most recent 50, oldest first)
router.get('/:roomId/messages', async (req, res) => {
  try {
    const room = await Room.findById(req.params.roomId);
    if (!room) return res.status(404).json({ message: 'Room not found' });

    const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);

    const messages = await Message.find({ room: req.params.roomId })
      .sort({ createdAt: -1 })
      .limit(limit)
      .lean();

    res.json({ messages: messages.reverse() });
  } catch (err) {
    if (err.kind === 'ObjectId') {
      return res.status(400).json({ message: 'Invalid room id' });
    }
    console.error(err);
    res.status(500).json({ message: 'Server error while fetching messages' });
  }
});

module.exports = router;
