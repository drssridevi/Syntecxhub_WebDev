# Task Manager (Full Stack)

A full-stack task management app with JWT authentication.

- **Frontend:** React (React Router, Axios)
- **Backend:** Node.js + Express
- **Database:** MongoDB (Mongoose)
- **Auth:** JWT, bcrypt-hashed passwords, protected routes via middleware

## Features

- Register / log in with email + password
- JWT issued on login/register, stored in `localStorage`, sent as `Authorization: Bearer <token>`
- Create, read, update, delete tasks (title, description, status, priority, due date)
- Tasks are scoped per-user — the `auth` middleware attaches `req.userId` and every task query is filtered by it
- Filter tasks by status
- Click a task's status badge to cycle pending → in-progress → completed

## Project Structure

```
task-manager/
├── backend/
│   ├── models/          # User, Task Mongoose schemas
│   ├── middleware/       # JWT auth middleware
│   ├── routes/           # /api/auth, /api/tasks
│   ├── server.js
│   └── .env.example
└── frontend/
    ├── public/
    └── src/
        ├── api/          # axios instance w/ JWT interceptor
        ├── context/      # AuthContext (login/register/logout state)
        └── components/   # Login, Register, TaskList, TaskForm, PrivateRoute
```

## Setup

### Prerequisites
- Node.js 18+
- MongoDB running locally, or a MongoDB Atlas connection string

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
# edit .env: set MONGO_URI and a strong JWT_SECRET
npm run dev      # or: npm start
```

The API runs on `http://localhost:5000` by default.

### 2. Frontend

```bash
cd frontend
npm install
cp .env.example .env
# edit .env if your backend runs on a different URL
npm start
```

The app runs on `http://localhost:3000` and talks to the API at the URL set in `REACT_APP_API_URL`.

## API Reference

| Method | Endpoint            | Auth required | Description                  |
|--------|---------------------|:-------------:|-------------------------------|
| POST   | /api/auth/register  | No            | Create account, returns JWT   |
| POST   | /api/auth/login     | No            | Log in, returns JWT           |
| GET    | /api/auth/me        | Yes           | Get current user              |
| GET    | /api/tasks          | Yes           | List tasks (`?status=`, `?search=`) |
| GET    | /api/tasks/:id      | Yes           | Get single task               |
| POST   | /api/tasks          | Yes           | Create task                   |
| PUT    | /api/tasks/:id      | Yes           | Update task                   |
| DELETE | /api/tasks/:id      | Yes           | Delete task                   |

All `/api/tasks` routes require an `Authorization: Bearer <token>` header. The middleware in
`backend/middleware/auth.js` verifies the JWT and rejects missing/invalid/expired tokens with 401.

## Security notes

- Passwords are hashed with bcrypt before being stored (never stored in plain text)
- JWTs are signed with a secret from `.env` (never commit your real `.env`)
- Every task route is protected by the `auth` middleware, and every DB query is scoped to
  `req.userId` so users can only see/edit/delete their own tasks
- CORS is enabled on the backend for local development; restrict `origin` in production

## Next steps / ideas

- Add refresh tokens for longer sessions
- Add pagination or infinite scroll for large task lists
- Add task categories/tags
- Deploy backend (Render/Railway/Fly.io) + frontend (Vercel/Netlify) + MongoDB Atlas
